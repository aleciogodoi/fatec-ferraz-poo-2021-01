package ExemploDAO;

public class TesteUsuario {

	public static void main(String[] args) {
		System.out.println(UsuarioDAO.find(1));
	}

}
